import { ProjectReflection } from 'typedoc';
import { ComponentDefinition } from './interfaces';
export default function extractComponents(publicFilesGlob: string, project: ProjectReflection): ComponentDefinition[];
