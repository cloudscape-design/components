import { ComponentDefinition } from './interfaces';
export declare function documentComponents(tsconfigPath: string, publicFilesGlob: string): ComponentDefinition[];
