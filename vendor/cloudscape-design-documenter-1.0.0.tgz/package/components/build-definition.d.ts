import { DeclarationReflection } from 'typedoc';
import { ComponentDefinition } from './interfaces';
export default function buildDefinition(component: DeclarationReflection, props: DeclarationReflection[], objects: DeclarationReflection[]): ComponentDefinition;
