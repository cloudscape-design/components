"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const path = __importStar(require("path"));
const pathe_1 = require("pathe");
const micromatch_1 = require("micromatch");
const change_case_1 = require("change-case");
const typedoc_1 = require("typedoc");
const build_definition_1 = __importDefault(require("./build-definition"));
const schema_1 = __importDefault(require("../schema"));
function returnsReactContent(node) {
    var _a;
    return (_a = node.signatures) === null || _a === void 0 ? void 0 : _a.some(({ type }) => schema_1.default.types.isReferenceType(type) &&
        (type.symbolFullyQualifiedName.endsWith('JSX.Element') ||
            type.symbolFullyQualifiedName.endsWith('React.ReactPortal')));
}
function findComponent(module) {
    if (!module.children) {
        return null;
    }
    const components = [];
    for (const child of module.children) {
        if (child.flags.isExported) {
            switch (child.kind) {
                case typedoc_1.ReflectionKind.Function:
                    if (returnsReactContent(child)) {
                        components.push(child);
                    }
                    break;
                case typedoc_1.ReflectionKind.Variable:
                    if (schema_1.default.utils.isForwardRefDeclaration(child)) {
                        components.push(child);
                    }
                    break;
            }
        }
    }
    if (components.length > 1) {
        throw new Error(`Found multiple exported components in ${module.name}: ${components.map(child => child.name).join(', ')}`);
    }
    return components[0];
}
function findProps(allDefinitions, propsName, directoryName) {
    const props = [];
    const objectInterfaces = [];
    for (const child of allDefinitions) {
        if (child.name !== propsName || !schema_1.default.utils.getDeclarationSourceFilename(child).includes(directoryName)) {
            continue;
        }
        if (child.kind === typedoc_1.ReflectionKind.Interface && child.children) {
            props.push(...child.children);
        }
        if (child.kind === typedoc_1.ReflectionKind.Namespace && child.children) {
            for (const subChild of child.children) {
                switch (subChild.kind) {
                    case typedoc_1.ReflectionKind.TypeAlias:
                    case typedoc_1.ReflectionKind.Interface:
                        objectInterfaces.push(subChild);
                        break;
                    case typedoc_1.ReflectionKind.Property:
                        props.push(subChild);
                        break;
                    default:
                        throw new Error(`Unknown type ${subChild.kindString} inside of ${propsName} at ${schema_1.default.utils.getDeclarationSourceFilename(subChild)}`);
                }
            }
        }
    }
    return {
        props: props,
        objects: objectInterfaces,
    };
}
function extractComponents(publicFilesGlob, project) {
    const definitions = [];
    const isMatch = (0, micromatch_1.matcher)((0, pathe_1.resolve)(publicFilesGlob));
    if (!project.children) {
        return [];
    }
    const allDefinitions = project.children.flatMap(module => {
        if (!module.children) {
            throw new Error(`Module ${module.originalName} does not contain a definition.`);
        }
        // Hack: Don't include sub version folders as they include duplicate interfaces
        // TODO: Remove once Top Navigation has launched: (AWSUI-15424)
        if (module.originalName.indexOf('-beta') > -1) {
            return [];
        }
        return module.children;
    });
    const publicModules = project.children.filter(module => isMatch(module.originalName));
    publicModules.forEach(module => {
        const component = findComponent(module);
        if (component) {
            const directoryName = path.dirname(module.originalName);
            if (component.name !== (0, change_case_1.pascalCase)(path.basename(directoryName))) {
                throw new Error(`Component ${component.name} is exported from a mismatched folder: ${directoryName}`);
            }
            const propsNamespace = `${component.name}Props`;
            const { props, objects } = findProps(allDefinitions, propsNamespace, directoryName);
            definitions.push((0, build_definition_1.default)(component, props, objects));
        }
    });
    return definitions;
}
exports.default = extractComponents;
