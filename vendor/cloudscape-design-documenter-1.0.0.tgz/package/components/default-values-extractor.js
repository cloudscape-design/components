"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractFromSource = void 0;
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const ts = __importStar(require("typescript"));
const schema_1 = __importDefault(require("../schema"));
function extractDefaultValues(component) {
    var _a, _b, _c;
    const callSignature = (_c = (_b = (_a = component.signatures) === null || _a === void 0 ? void 0 : _a[0].parameters) === null || _b === void 0 ? void 0 : _b[0].type) === null || _c === void 0 ? void 0 : _c.declaration;
    if (callSignature) {
        return extractFromCallSignature(callSignature);
    }
    if (schema_1.default.utils.isForwardRefDeclaration(component) && component.defaultValue) {
        // TypeDoc does look inside React.forwardRef content, so we need to parse
        // typescript manually to extract values from object destructuring
        return extractFromSource(component.defaultValue);
    }
    return {};
}
exports.default = extractDefaultValues;
function extractFromSource(sourceCode) {
    const node = ts.createSourceFile('temp.ts', sourceCode, ts.ScriptTarget.Latest);
    const statement = node.statements[0];
    if (!ts.isExpressionStatement(statement)) {
        return {};
    }
    let expression = statement.expression;
    if (ts.isAsExpression(expression)) {
        expression = expression.expression;
    }
    if (ts.isCallExpression(expression)) {
        expression = expression.arguments[0];
    }
    if (!ts.isArrowFunction(expression) && !ts.isFunctionExpression(expression)) {
        return {};
    }
    const props = expression.parameters[0];
    if (!ts.isObjectBindingPattern(props.name)) {
        return {};
    }
    const values = {};
    for (const element of props.name.elements) {
        if (ts.isIdentifier(element.name) && element.initializer) {
            values[element.name.escapedText] = sourceCode
                .substring(element.initializer.pos, element.initializer.end)
                .trim();
        }
    }
    return values;
}
exports.extractFromSource = extractFromSource;
function extractFromCallSignature(callSignature) {
    const values = {};
    for (const child of callSignature.children || []) {
        if (child.defaultValue) {
            values[child.name] = child.defaultValue;
        }
    }
    return values;
}
