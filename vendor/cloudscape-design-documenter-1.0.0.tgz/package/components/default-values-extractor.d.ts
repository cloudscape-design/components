import { DeclarationReflection } from 'typedoc';
export default function extractDefaultValues(component: DeclarationReflection): Record<string, any>;
export declare function extractFromSource(sourceCode: string): Record<string, any>;
