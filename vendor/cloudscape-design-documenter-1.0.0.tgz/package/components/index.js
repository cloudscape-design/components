"use strict";
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.documentComponents = void 0;
const components_extractor_1 = __importDefault(require("./components-extractor"));
const bootstrap_1 = require("../bootstrap");
function documentComponents(tsconfigPath, publicFilesGlob) {
    const project = (0, bootstrap_1.bootstrapProject)({ tsconfig: tsconfigPath });
    return (0, components_extractor_1.default)(publicFilesGlob, project);
}
exports.documentComponents = documentComponents;
