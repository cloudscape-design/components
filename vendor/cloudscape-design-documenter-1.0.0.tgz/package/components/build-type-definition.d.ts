import { DeclarationReflection } from 'typedoc';
import { FunctionDefinition, ObjectDefinition, UnionTypeDefinition } from './interfaces';
export default function buildTypeDefinition(obj: DeclarationReflection): ObjectDefinition | FunctionDefinition | UnionTypeDefinition;
