"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const schema_1 = __importDefault(require("../schema"));
function buildObjectDefinition(obj) {
    var _a, _b;
    return {
        name: schema_1.default.code.buildFullName(obj),
        type: 'object',
        properties: (_b = (_a = obj.children) === null || _a === void 0 ? void 0 : _a.map(prop => ({
            name: prop.name,
            type: prop.signatures ? schema_1.default.code.buildCallSignature(prop.signatures[0]) : schema_1.default.code.buildType(prop.type),
            optional: schema_1.default.utils.isOptionalDeclaration(prop),
        }))) !== null && _b !== void 0 ? _b : [],
    };
}
function buildFunctionDefinition(obj, signature) {
    var _a, _b;
    return {
        name: schema_1.default.code.buildFullName(obj),
        type: 'function',
        returnType: schema_1.default.code.buildType(signature.type),
        parameters: (_b = (_a = signature.parameters) === null || _a === void 0 ? void 0 : _a.map(parameter => ({
            name: parameter.name,
            type: schema_1.default.code.buildType(parameter.type),
        }))) !== null && _b !== void 0 ? _b : [],
    };
}
function buildUnionTypeDefinition(obj, type) {
    return {
        name: schema_1.default.code.buildFullName(obj),
        type: 'union',
        values: type.types.map(type => {
            const result = schema_1.default.code.buildType(type);
            try {
                return JSON.parse(result);
            }
            catch (e) {
                // ignore json parse errors
            }
            return result;
        }),
    };
}
function buildTypeDefinition(obj) {
    // Use the original public name (e.g. ComponentProps.Something) for type aliases
    const fullName = schema_1.default.code.buildFullName(obj);
    if (schema_1.default.types.isReflectionType(obj.type)) {
        obj = obj.type.declaration;
    }
    let definition;
    if (schema_1.default.types.isUnionType(obj.type)) {
        definition = buildUnionTypeDefinition(obj, obj.type);
    }
    if (obj.signatures) {
        definition = buildFunctionDefinition(obj.parent, obj.signatures[0]);
    }
    if (schema_1.default.types.isReferenceType(obj.type) && obj.type.reflection) {
        definition = buildObjectDefinition(obj.type.reflection);
    }
    if (!definition) {
        definition = buildObjectDefinition(obj);
    }
    definition.name = fullName;
    return definition;
}
exports.default = buildTypeDefinition;
