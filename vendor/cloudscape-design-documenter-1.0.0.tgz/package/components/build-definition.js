"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
const typedoc_1 = require("typedoc");
const schema_1 = __importDefault(require("../schema"));
const build_type_definition_1 = __importDefault(require("./build-type-definition"));
const default_values_extractor_1 = __importDefault(require("./default-values-extractor"));
function buildEventInfo(handler) {
    var _a, _b, _c, _d;
    if (!schema_1.default.types.isReferenceType(handler.type)) {
        throw new Error(`Unknown event handler type: ${handler.type && handler.type.type} at ${schema_1.default.utils.getDeclarationSourceFilename(handler)}`);
    }
    const detailType = (_a = handler.type.typeArguments) === null || _a === void 0 ? void 0 : _a[0];
    const { typeName, typeDefinition } = detailType
        ? getPropertyType(detailType)
        : { typeName: undefined, typeDefinition: undefined };
    return {
        name: handler.name,
        description: schema_1.default.code.buildNodeDescription(handler),
        cancelable: handler.type.name !== 'NonCancelableEventHandler',
        detailType: typeName,
        detailInlineType: typeDefinition,
        deprecatedTag: (_d = (_c = (_b = handler.comment) === null || _b === void 0 ? void 0 : _b.tags) === null || _c === void 0 ? void 0 : _c.find(tag => tag.tagName === 'deprecated')) === null || _d === void 0 ? void 0 : _d.text.trim(),
    };
}
function buildMethodsDefinition(refType) {
    if (!refType || !refType.children) {
        return [];
    }
    return refType.children.map(child => {
        var _a, _b;
        if (!child.signatures) {
            throw new Error(`${schema_1.default.code.buildFullName(child)} should contain only methods, "${child.name}" has a "${schema_1.default.code.buildType(child.type)}" type`);
        }
        if (child.signatures.length > 1) {
            throw new Error(`Method overloads are not supported, found multiple signatures at ${schema_1.default.utils.getDeclarationSourceFilename(child)}`);
        }
        const signature = child.signatures[0];
        return {
            name: child.name,
            description: schema_1.default.code.buildNodeDescription(signature),
            returnType: schema_1.default.code.buildType(signature.type),
            parameters: (_b = (_a = signature.parameters) === null || _a === void 0 ? void 0 : _a.map(parameter => ({
                name: parameter.name,
                type: schema_1.default.code.buildType(parameter.type),
            }))) !== null && _b !== void 0 ? _b : [],
        };
    });
}
function getPropertyType(type) {
    const typeAlias = schema_1.default.types.isReferenceType(type) && type.reflection;
    const resolvedType = typeAlias ? typeAlias.type : type;
    if (schema_1.default.types.isUnionType(resolvedType)) {
        const subTypes = schema_1.default.utils.excludeUndefinedTypeFromUnion(resolvedType);
        if (subTypes.length > 1) {
            if (subTypes.every(type => schema_1.default.types.isStringLiteralType(type))) {
                const referenceTypeName = schema_1.default.types.isReferenceType(type) ? schema_1.default.code.buildType(type) : '';
                const declaration = new typedoc_1.DeclarationReflection(referenceTypeName, typedoc_1.ReflectionKind.TypeLiteral);
                declaration.type = resolvedType;
                return {
                    typeName: 'string',
                    typeDefinition: (0, build_type_definition_1.default)(declaration),
                };
            }
            if (subTypes.every(type => schema_1.default.types.isIntrinsicType(type) && (type.name === 'true' || type.name === 'false'))) {
                return { typeName: 'boolean' };
            }
        }
    }
    return {
        typeName: schema_1.default.code.buildType(type),
        typeDefinition: typeAlias ? (0, build_type_definition_1.default)(typeAlias) : undefined,
    };
}
function buildDefinition(component, props, objects) {
    var _a, _b, _c, _d;
    const events = props.filter(prop => prop.name.match(/^on[A-Z]/));
    const regions = props.filter(prop => ['React.ReactNode', 'ReactNode'].includes(schema_1.default.code.buildType(prop.type)));
    const onlyProps = props.filter(prop => !events.includes(prop) && !regions.includes(prop));
    const defaultValues = (0, default_values_extractor_1.default)(component);
    const betaTag = component.signatures && ((_b = (_a = component.signatures[0].comment) === null || _a === void 0 ? void 0 : _a.tags) === null || _b === void 0 ? void 0 : _b.find(tag => tag.tagName === 'beta'));
    const versionTag = component.signatures && ((_d = (_c = component.signatures[0].comment) === null || _c === void 0 ? void 0 : _c.tags) === null || _d === void 0 ? void 0 : _d.find(tag => tag.tagName === 'version'));
    return {
        name: component.name,
        version: versionTag === null || versionTag === void 0 ? void 0 : versionTag.text.trim().replace('\n', ''),
        releaseStatus: betaTag ? 'beta' : 'stable',
        description: schema_1.default.code.buildDeclarationDescription(component),
        regions: regions.map(region => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
            return {
                name: region.name,
                displayName: (_c = (_b = (_a = region.comment) === null || _a === void 0 ? void 0 : _a.tags) === null || _b === void 0 ? void 0 : _b.find(tag => tag.tagName === 'displayname')) === null || _c === void 0 ? void 0 : _c.text.trim(),
                description: schema_1.default.code.buildNodeDescription(region),
                isDefault: region.name === 'children',
                visualRefreshTag: (_f = (_e = (_d = region.comment) === null || _d === void 0 ? void 0 : _d.tags) === null || _e === void 0 ? void 0 : _e.find(tag => tag.tagName === 'visualrefresh')) === null || _f === void 0 ? void 0 : _f.text.trim(),
                deprecatedTag: (_j = (_h = (_g = region.comment) === null || _g === void 0 ? void 0 : _g.tags) === null || _h === void 0 ? void 0 : _h.find(tag => tag.tagName === 'deprecated')) === null || _j === void 0 ? void 0 : _j.text.trim(),
                i18nTag: ((_l = (_k = region.comment) === null || _k === void 0 ? void 0 : _k.tags) === null || _l === void 0 ? void 0 : _l.some(tag => tag.tagName === 'i18n')) || undefined,
            };
        }),
        functions: buildMethodsDefinition(objects.find(def => def.name === 'Ref')),
        properties: onlyProps.map(prop => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
            const { typeName, typeDefinition } = getPropertyType(prop.type);
            return {
                name: prop.name,
                type: typeName,
                inlineType: typeDefinition,
                optional: schema_1.default.utils.isOptionalDeclaration(prop),
                description: schema_1.default.code.buildNodeDescription(prop),
                defaultValue: defaultValues[prop.name],
                visualRefreshTag: (_c = (_b = (_a = prop.comment) === null || _a === void 0 ? void 0 : _a.tags) === null || _b === void 0 ? void 0 : _b.find(tag => tag.tagName === 'visualrefresh')) === null || _c === void 0 ? void 0 : _c.text.trim(),
                deprecatedTag: (_f = (_e = (_d = prop.comment) === null || _d === void 0 ? void 0 : _d.tags) === null || _e === void 0 ? void 0 : _e.find(tag => tag.tagName === 'deprecated')) === null || _f === void 0 ? void 0 : _f.text.trim(),
                i18nTag: ((_h = (_g = prop.comment) === null || _g === void 0 ? void 0 : _g.tags) === null || _h === void 0 ? void 0 : _h.some(tag => tag.tagName === 'i18n')) || undefined,
                analyticsTag: (_l = (_k = (_j = prop.comment) === null || _j === void 0 ? void 0 : _j.tags) === null || _k === void 0 ? void 0 : _k.find(tag => tag.tagName === 'analytics')) === null || _l === void 0 ? void 0 : _l.text.trim(),
            };
        }),
        events: events.map(handler => buildEventInfo(handler)),
    };
}
exports.default = buildDefinition;
