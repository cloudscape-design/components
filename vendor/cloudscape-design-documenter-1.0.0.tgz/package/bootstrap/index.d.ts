import { TypeDocAndTSOptions, ProjectReflection } from 'typedoc';
export declare function bootstrapProject(options: Partial<TypeDocAndTSOptions>, filteringGlob?: string): ProjectReflection;
