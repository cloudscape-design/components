import { DeclarationReflection } from 'typedoc/dist/lib/models';
import { TestUtilMethod } from '../interfaces';
export declare function getMethodsDoc(childReflections?: Array<DeclarationReflection>): Array<TestUtilMethod>;
