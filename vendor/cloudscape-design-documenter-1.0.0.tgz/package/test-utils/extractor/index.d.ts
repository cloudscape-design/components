import { ProjectReflection } from 'typedoc';
import { TestUtilsDoc } from '../interfaces';
export default function extractRelevantDocumentation(project: ProjectReflection): TestUtilsDoc[];
