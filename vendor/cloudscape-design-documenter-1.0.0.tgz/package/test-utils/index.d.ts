import { TypeDocAndTSOptions } from 'typedoc';
import { TestUtilsDoc } from './interfaces';
export declare function documentTestUtils(options: Partial<TypeDocAndTSOptions>, filteringGlob: string): Array<TestUtilsDoc>;
