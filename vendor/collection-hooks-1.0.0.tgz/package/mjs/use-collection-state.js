// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useReducer, useMemo } from 'react';
import { createActions, collectionReducer } from './utils.js';
import { warnOnce } from './logging.js';
// Normalizes the polymorphic `sorting.defaultState` option into the internal always-array shape.
// The `sorting` option is a discriminated union: `defaultState` is a single descriptor in single-column
// mode and an array in multi-column mode. TypeScript enforces this, but for untyped (JS) consumers we
// verify the runtime shape and emit a dev-only warning on a mismatch, recovering gracefully so a wrong
// shape never throws in production.
function isSortingStateArray(value) {
    return Array.isArray(value);
}
function normalizeDefaultSorting(sorting) {
    if (!sorting || sorting.defaultState === undefined) {
        return [];
    }
    const defaultState = sorting.defaultState;
    if (sorting.multiColumn) {
        if (isSortingStateArray(defaultState)) {
            return defaultState;
        }
        warnOnce('`sorting.defaultState` must be an array of sorting states when `sorting.multiColumn` is enabled.');
        return [defaultState];
    }
    if (isSortingStateArray(defaultState)) {
        warnOnce('`sorting.defaultState` must be a single sorting state unless `sorting.multiColumn` is enabled.');
        return defaultState.slice(0, 1);
    }
    return [defaultState];
}
export function useCollectionState(options, collectionRef) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    const sorting = options.sorting;
    const initialSortingColumns = normalizeDefaultSorting(sorting);
    const [state, dispatch] = useReducer(collectionReducer, {
        selectedItems: (_b = (_a = options.selection) === null || _a === void 0 ? void 0 : _a.defaultSelectedItems) !== null && _b !== void 0 ? _b : [],
        expandedItems: (_d = (_c = options.expandableRows) === null || _c === void 0 ? void 0 : _c.defaultExpandedItems) !== null && _d !== void 0 ? _d : [],
        sortingColumns: initialSortingColumns,
        currentPageIndex: (_f = (_e = options.pagination) === null || _e === void 0 ? void 0 : _e.defaultPage) !== null && _f !== void 0 ? _f : 1,
        filteringText: (_h = (_g = options.filtering) === null || _g === void 0 ? void 0 : _g.defaultFilteringText) !== null && _h !== void 0 ? _h : '',
        propertyFilteringQuery: (_k = (_j = options.propertyFiltering) === null || _j === void 0 ? void 0 : _j.defaultQuery) !== null && _k !== void 0 ? _k : { tokens: [], operation: 'and' },
        groupSelection: { inverted: false, toggledItems: (_m = (_l = options.selection) === null || _l === void 0 ? void 0 : _l.defaultSelectedItems) !== null && _m !== void 0 ? _m : [] },
    });
    const actions = useMemo(() => createActions({ dispatch, collectionRef }), [dispatch, collectionRef]);
    return [state, actions];
}
