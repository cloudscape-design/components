// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
import { useRef, useMemo } from 'react';
import { processItems, processSelectedItems, itemsAreEqual } from './operations/index.js';
import { createSyncProps, computeFilteringOptions } from './utils.js';
import { useCollectionState } from './use-collection-state.js';
export function useCollection(allItems, options) {
    var _a, _b;
    const collectionRef = useRef(null);
    const [state, actions] = useCollectionState(options, collectionRef);
    const filteringProperties = (_a = options.propertyFiltering) === null || _a === void 0 ? void 0 : _a.filteringProperties;
    const { items, allPageItems, pagesCount, totalItemsCount, filteredItemsCount, actualPageIndex, selectedItems, expandableRows, } = processItems(allItems, state, options);
    const expandedItemsSet = new Set();
    if (options.expandableRows) {
        for (const item of state.expandedItems) {
            expandedItemsSet.add(options.expandableRows.getId(item));
        }
    }
    let visibleItems = items;
    if (options.expandableRows) {
        const flatItems = new Array();
        const getId = options.expandableRows.getId;
        const traverse = (items) => {
            for (const item of items) {
                flatItems.push(item);
                if (expandableRows && expandedItemsSet.has(getId(item))) {
                    traverse(expandableRows.getItemChildren(item));
                }
            }
        };
        traverse(items);
        visibleItems = flatItems;
    }
    // Removing selected items that are no longer present in items unless keepSelection=true.
    if (options.selection && !options.selection.keepSelection) {
        const newSelectedItems = processSelectedItems(visibleItems, state.selectedItems, options.selection.trackBy);
        if (!itemsAreEqual(newSelectedItems, state.selectedItems, options.selection.trackBy)) {
            // This is a recommended pattern for how to handle the state, dependent on the incoming props
            // https://reactjs.org/docs/hooks-faq.html#how-do-i-implement-getderivedstatefromprops
            actions.setSelectedItems(newSelectedItems);
        }
    }
    // Removing expanded items that are no longer present in items.
    if (options.expandableRows) {
        const newExpandedItems = visibleItems.filter(item => expandedItemsSet.has(options.expandableRows.getId(item)));
        if (!itemsAreEqual(newExpandedItems, state.expandedItems, options.expandableRows.getId)) {
            actions.setExpandedItems(newExpandedItems);
        }
    }
    const externalFilteringOptions = (_b = options.propertyFiltering) === null || _b === void 0 ? void 0 : _b.filteringOptions;
    const filteringOptions = useMemo(() => externalFilteringOptions !== null && externalFilteringOptions !== void 0 ? externalFilteringOptions : computeFilteringOptions(allItems, filteringProperties), [allItems, filteringProperties, externalFilteringOptions]);
    // When normal selection is used, the selectedItems are taken from state.
    // When group selection is used, the selectedItems are derived from group selection state.
    const extendedState = selectedItems ? Object.assign(Object.assign({}, state), { selectedItems }) : state;
    return Object.assign({ items,
        allPageItems,
        filteredItemsCount,
        actions }, createSyncProps(options, extendedState, actions, collectionRef, {
        actualPageIndex,
        pagesCount,
        allItems,
        totalItemsCount,
        expandableRows,
        filteringOptions,
    }));
}
