// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
export function computeFlatItems(items, filterPredicate, sortingComparator) {
    if (filterPredicate) {
        items = items.filter(filterPredicate);
    }
    if (sortingComparator) {
        items = items.slice().sort(sortingComparator);
    }
    return {
        items,
        rootItemsCount: items.length,
        selectableItemsCount: items.length,
        getItemChildren: undefined,
        isItemExpandable: undefined,
        getItemsCount: undefined,
    };
}
export function computeTreeItems(allItems, treeProps, filterPredicate, sortingComparator) {
    var _a;
    const idToChildren = new Map();
    const idToCount = new Map();
    let items = [];
    let rootItemsCount = 0;
    let selectableItemsCount = 0;
    for (const item of allItems) {
        const parentId = treeProps.getParentId(item);
        if (parentId === null) {
            items.push(item);
        }
        else {
            const children = (_a = idToChildren.get(parentId)) !== null && _a !== void 0 ? _a : [];
            children.push(item);
            idToChildren.set(parentId, children);
        }
    }
    const getItemChildren = (item) => { var _a; return (_a = idToChildren.get(treeProps.getId(item))) !== null && _a !== void 0 ? _a : []; };
    const setChildren = (item, children) => idToChildren.set(treeProps.getId(item), children);
    const isItemExpandable = (item) => { var _a; return ((_a = getItemChildren(item)) === null || _a === void 0 ? void 0 : _a.length) > 0; };
    if (filterPredicate) {
        const filterNode = (item) => {
            const children = getItemChildren(item);
            const filteredChildren = children.filter(filterNode);
            setChildren(item, filteredChildren);
            return filterPredicate(item) || filteredChildren.length > 0;
        };
        items = items.filter(filterNode);
    }
    if (sortingComparator) {
        const sortLevel = (levelItems) => {
            levelItems.sort(sortingComparator);
            for (const item of levelItems) {
                sortLevel(getItemChildren(item));
            }
        };
        sortLevel(items);
    }
    function computeSelectableCount(item) {
        const children = getItemChildren(item);
        // In grouped table, we count all leaf nodes as selectable.
        let itemCount = children.length === 0 ? 1 : 0;
        for (const child of children) {
            itemCount += computeSelectableCount(child);
        }
        idToCount.set(treeProps.getId(item), itemCount);
        return itemCount;
    }
    for (const item of items) {
        rootItemsCount += 1;
        selectableItemsCount += computeSelectableCount(item);
    }
    const getItemsCount = treeProps.dataGrouping ? (item) => { var _a; return (_a = idToCount.get(treeProps.getId(item))) !== null && _a !== void 0 ? _a : 0; } : undefined;
    return { items, rootItemsCount, selectableItemsCount, getItemChildren, isItemExpandable, getItemsCount };
}
