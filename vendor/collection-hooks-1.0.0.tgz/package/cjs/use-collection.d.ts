import { UseCollectionOptions, UseCollectionResult } from './interfaces';
export declare function useCollection<T>(allItems: ReadonlyArray<T>, options: UseCollectionOptions<T>): UseCollectionResult<T>;
