import { UseCollectionOptions, CollectionState, CollectionRef, CollectionActions } from './interfaces';
export declare function useCollectionState<T>(options: UseCollectionOptions<T>, collectionRef: React.RefObject<CollectionRef>): readonly [CollectionState<T>, CollectionActions<T>];
