/**
 * Compares dates up to a day.
 * @param date - item value as Date.
 * @param dateToCompare - token value as ISO8601 date string.
 * @returns diff in milliseconds between date and dateToCompare with a step of one day.
 */
export declare function compareDates(date: Date, dateToCompare: string): number;
/**
 * Compares dates up to a millisecond.
 * @param date - item value as Date.
 * @param dateToCompare - token value as ISO8601 date string.
 * @returns diff in milliseconds between date and dateToCompare with a step of one millisecond.
 */
export declare function compareTimestamps(date: Date, dateToCompare: string): number;
