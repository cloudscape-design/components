/**
 * Minimal global type shims for environments without @types/node.
 * Only declare types not provided by lib.dom to avoid conflicts.
 */
declare global {
    const process: {
        env: {
            NODE_ENV?: string;
        };
    };
}
export {};
