export { processItems, processSelectedItems } from './operations/index.js';
