import * as React from 'react';
interface CustomEventLike<T> {
    detail: T;
}
export interface FilteringOptions<T> {
    filteringFunction?: (item: T, filteringText: string, filteringFields?: string[]) => boolean;
    fields?: string[];
}
export interface SortingState<T> {
    isDescending?: boolean;
    sortingColumn: SortingColumn<T>;
}
export interface SortingColumn<T> {
    sortingField?: string;
    sortingComparator?: (a: T, b: T) => number;
}
export interface MultiColumnSortChangeDetail<T> {
    sortingColumns: ReadonlyArray<SortingState<T>>;
}
export interface SelectionChangeDetail<T> {
    selectedItems: ReadonlyArray<T>;
}
export interface GroupSelectionState<T> {
    inverted: boolean;
    toggledItems: readonly T[];
}
export interface GroupSelectionChangeDetail<T> {
    groupSelection: GroupSelectionState<T>;
}
export type TrackBy<T> = string | ((item: T) => string);
export interface UseCollectionOptions<T> {
    filtering?: FilteringOptions<T> & {
        empty?: React.ReactNode;
        noMatch?: React.ReactNode;
        defaultFilteringText?: string;
    };
    propertyFiltering?: {
        empty?: React.ReactNode;
        noMatch?: React.ReactNode;
        filteringProperties: readonly PropertyFilterProperty[];
        filteringOptions?: PropertyFilterOption[];
        filteringFunction?: (item: T, query: PropertyFilterQuery) => boolean;
        defaultQuery?: PropertyFilterQuery;
        freeTextFiltering?: PropertyFilterFreeTextFiltering;
    };
    sorting?: {
        /**
         * Enables multi-column sorting.
         *
         * @defaultValue false
         */
        multiColumn?: false;
        /**
         * Initial sort state.
         */
        defaultState?: SortingState<T>;
    } | {
        /**
         * Enables multi-column sorting.
         */
        multiColumn: true;
        /**
         * Initial sort state as an array of descriptors in priority order (the first entry has the highest priority).
         */
        defaultState?: ReadonlyArray<SortingState<T>>;
    };
    pagination?: {
        defaultPage?: number;
        pageSize?: number;
        allowPageOutOfRange?: boolean;
    };
    selection?: {
        defaultSelectedItems?: ReadonlyArray<T>;
        keepSelection?: boolean;
        trackBy?: TrackBy<T>;
    };
    expandableRows?: ExpandableRowsProps<T>;
}
export interface ExpandableRowsProps<ItemType> {
    getId(item: ItemType): string;
    getParentId(item: ItemType): null | string;
    defaultExpandedItems?: ReadonlyArray<ItemType>;
    dataGrouping?: DataGroupingProps;
}
export interface DataGroupingProps {
}
export interface CollectionState<T> {
    filteringText: string;
    propertyFilteringQuery: PropertyFilterQuery;
    currentPageIndex: number;
    sortingColumns: ReadonlyArray<SortingState<T>>;
    selectedItems: ReadonlyArray<T>;
    expandedItems: ReadonlyArray<T>;
    groupSelection: GroupSelectionState<T>;
}
export interface CollectionActions<T> {
    setFiltering(filteringText: string): void;
    setCurrentPage(pageNumber: number): void;
    setSorting(state: SortingState<T>): void;
    setMultiSorting(sortingColumns: ReadonlyArray<SortingState<T>>): void;
    setSelectedItems(selectedItems: ReadonlyArray<T>): void;
    setPropertyFiltering(query: PropertyFilterQuery): void;
    setExpandedItems(items: ReadonlyArray<T>): void;
    setGroupSelection(state: GroupSelectionState<T>): void;
}
interface UseCollectionResultBase<T> {
    items: ReadonlyArray<T>;
    allPageItems: ReadonlyArray<T>;
    actions: CollectionActions<T>;
    collectionProps: {
        empty?: React.ReactNode;
        onSortingChange?(event: CustomEventLike<SortingState<T>>): void;
        sortingColumn?: SortingColumn<T>;
        sortingDescending?: boolean;
        multiColumnSort?: {
            sortingColumns: ReadonlyArray<SortingState<T>>;
            onChange(event: CustomEventLike<MultiColumnSortChangeDetail<T>>): void;
        };
        selectedItems?: ReadonlyArray<T>;
        onSelectionChange?(event: CustomEventLike<SelectionChangeDetail<T>>): void;
        expandableRows?: ExpandableRowsResult<T>;
        trackBy?: string | ((item: T) => string);
        ref: React.RefObject<CollectionRef>;
        totalItemsCount: number;
        firstIndex: number;
    };
    filterProps: {
        disabled?: boolean;
        filteringText: string;
        onChange(event: CustomEventLike<{
            filteringText: string;
        }>): void;
    };
    propertyFilterProps: {
        query: PropertyFilterQuery;
        onChange(event: CustomEventLike<PropertyFilterQuery>): void;
        filteringProperties: readonly PropertyFilterProperty[];
        filteringOptions: readonly PropertyFilterOption[];
        freeTextFiltering?: PropertyFilterFreeTextFiltering;
    };
    paginationProps: {
        disabled?: boolean;
        currentPageIndex: number;
        onChange(event: CustomEventLike<{
            currentPageIndex: number;
        }>): void;
    };
}
export interface ExpandableRowsResultBase<T> {
    getItemChildren: (item: T) => T[];
    isItemExpandable: (item: T) => boolean;
    getItemsCount?: (item: T) => number;
    totalItemsCount: number;
    getSelectedItemsCount?: (item: T) => number;
    totalSelectedItemsCount: number;
}
export interface ExpandableRowsResult<T> extends ExpandableRowsResultBase<T> {
    expandedItems: ReadonlyArray<T>;
    onExpandableItemToggle(event: CustomEventLike<{
        item: T;
        expanded: boolean;
    }>): void;
    groupSelection?: GroupSelectionState<T>;
    onGroupSelectionChange(event: CustomEventLike<GroupSelectionChangeDetail<T>>): void;
}
export interface UseCollectionResult<T> extends UseCollectionResultBase<T> {
    filteredItemsCount: number | undefined;
    paginationProps: UseCollectionResultBase<T>['paginationProps'] & {
        pagesCount: number;
    };
}
export interface CollectionRef {
    scrollToTop: () => void;
}
export type PropertyFilterOperator = '<' | '<=' | '>' | '>=' | ':' | '!:' | '=' | '!=' | '^' | string;
export interface PropertyFilterOperatorExtended<TokenValue> {
    operator: PropertyFilterOperator;
    tokenType?: PropertyFilterTokenType;
    match?: PropertyFilterOperatorMatch<TokenValue>;
    form?: PropertyFilterOperatorForm<TokenValue>;
    format?: PropertyFilterOperatorFormat<TokenValue>;
    description?: string;
}
export type PropertyFilterTokenType = 'value' | 'enum';
export type PropertyFilterOperatorMatch<TokenValue> = PropertyFilterOperatorMatchByType | PropertyFilterOperatorMatchCustom<TokenValue>;
export type PropertyFilterOperatorMatchByType = 'date' | 'datetime';
export type PropertyFilterOperatorMatchCustom<TokenValue> = (itemValue: unknown, tokenValue: TokenValue) => boolean;
export interface PropertyFilterTextOperatorExtended {
    operator: PropertyFilterOperator;
    match?: (item: unknown, text: string) => boolean;
}
export interface PropertyFilterOperatorFormProps<TokenValue> {
    value: null | TokenValue;
    onChange: (value: null | TokenValue) => void;
    filter?: string;
    operator: PropertyFilterOperator;
}
export type PropertyFilterOperatorForm<TokenValue> = React.FC<PropertyFilterOperatorFormProps<TokenValue>>;
export type PropertyFilterOperatorFormat<TokenValue> = (value: TokenValue) => string;
export type PropertyFilterOperation = 'and' | 'or';
export interface PropertyFilterToken {
    value: any;
    propertyKey?: string;
    operator: PropertyFilterOperator;
}
export interface PropertyFilterTokenGroup {
    operation: PropertyFilterOperation;
    tokens: readonly (PropertyFilterToken | PropertyFilterTokenGroup)[];
}
export interface PropertyFilterQuery {
    tokens: readonly PropertyFilterToken[];
    operation: PropertyFilterOperation;
    tokenGroups?: readonly (PropertyFilterToken | PropertyFilterTokenGroup)[];
}
export interface PropertyFilterProperty<TokenValue = any> {
    key: string;
    groupValuesLabel: string;
    propertyLabel: string;
    operators?: readonly (PropertyFilterOperator | PropertyFilterOperatorExtended<TokenValue>)[];
    defaultOperator?: PropertyFilterOperator;
    group?: string;
}
export interface PropertyFilterOption {
    propertyKey: string;
    value: string;
    label?: string;
    tags?: ReadonlyArray<string>;
    filteringTags?: ReadonlyArray<string>;
}
export interface PropertyFilterFreeTextFiltering {
    operators?: readonly (PropertyFilterOperator | PropertyFilterTextOperatorExtended)[];
    defaultOperator?: PropertyFilterOperator;
}
export {};
