import { UseCollectionOptions } from '../interfaces';
import { Predicate } from './compose-filters';
export declare function createFilterPredicate<T>(filtering: UseCollectionOptions<T>['filtering'], filteringText?: string): null | Predicate<T>;
