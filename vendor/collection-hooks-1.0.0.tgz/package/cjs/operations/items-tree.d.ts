import { DataGroupingProps } from '../interfaces';
interface TreeProps<T> {
    getId(item: T): string;
    getParentId(item: T): null | string;
    dataGrouping?: DataGroupingProps;
}
export declare function computeFlatItems<T>(items: readonly T[], filterPredicate: null | ((item: T) => boolean), sortingComparator: null | ((a: T, b: T) => number)): {
    items: readonly T[];
    rootItemsCount: number;
    selectableItemsCount: number;
    getItemChildren: undefined;
    isItemExpandable: undefined;
    getItemsCount: undefined;
};
export declare function computeTreeItems<T>(allItems: readonly T[], treeProps: TreeProps<T>, filterPredicate: null | ((item: T) => boolean), sortingComparator: null | ((a: T, b: T) => number)): {
    items: T[];
    rootItemsCount: number;
    selectableItemsCount: number;
    getItemChildren: (item: T) => T[];
    isItemExpandable: (item: T) => boolean;
    getItemsCount: ((item: T) => number) | undefined;
};
export {};
