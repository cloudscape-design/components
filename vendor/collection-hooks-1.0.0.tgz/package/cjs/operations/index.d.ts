import { UseCollectionOptions, CollectionState, TrackBy, ExpandableRowsResultBase } from '../interfaces';
export declare function processItems<T>(allItems: ReadonlyArray<T>, state: Partial<CollectionState<T>>, { filtering, sorting, pagination, propertyFiltering, expandableRows, selection }: UseCollectionOptions<T>): {
    items: readonly T[];
    allPageItems: readonly T[];
    pagesCount: number | undefined;
    actualPageIndex: number | undefined;
    totalItemsCount: number;
    filteredItemsCount: number | undefined;
    selectedItems: undefined | T[];
    expandableRows?: ExpandableRowsResultBase<T>;
};
export declare const processSelectedItems: <T>(items: ReadonlyArray<T>, selectedItems: ReadonlyArray<T>, trackBy?: TrackBy<T>) => T[];
export declare const itemsAreEqual: <T>(items1: ReadonlyArray<T>, items2: ReadonlyArray<T>, trackBy?: TrackBy<T>) => boolean;
