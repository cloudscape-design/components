import { UseCollectionOptions } from '../interfaces';
export declare function createPageProps<T>(pagination: UseCollectionOptions<T>['pagination'], currentPageIndex: undefined | number, items: ReadonlyArray<T>): null | {
    pageSize: number;
    pagesCount: number;
    pageIndex: number;
};
