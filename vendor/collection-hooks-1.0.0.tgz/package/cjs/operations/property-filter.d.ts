import { PropertyFilterFreeTextFiltering, PropertyFilterQuery, PropertyFilterToken, UseCollectionOptions, PropertyFilterProperty, PropertyFilterTokenGroup } from '../interfaces';
import { Predicate } from './compose-filters';
export declare function makeEvaluate<T>(filteringProperties: readonly PropertyFilterProperty[], freeTextFiltering?: PropertyFilterFreeTextFiltering): (item: T, tokenOrGroup: PropertyFilterToken | PropertyFilterTokenGroup) => boolean;
export declare function createPropertyFilterPredicate<T>(propertyFiltering: UseCollectionOptions<T>['propertyFiltering'], query?: PropertyFilterQuery): null | Predicate<T>;
export declare const fixupFalsyValues: <T>(value: T) => T | string;
